# Game-Of-Life
The Game of Life implemented using Raylib in C provides a graphical simulation of Conway’s Game of Life. Raylib is a simple and efficient C library for creating 2D and 3D games, making it ideal for visualizing cellular automata like Life.
